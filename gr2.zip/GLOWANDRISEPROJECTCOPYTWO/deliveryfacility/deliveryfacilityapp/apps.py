from django.apps import AppConfig


class DeliveryfacilityappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'deliveryfacilityapp'
