from django.shortcuts import render

# Create your views here.
"""

import json
import os
from django.http import JsonResponse
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
import logging

logger = logging.getLogger(__name__)

@csrf_exempt
def add_to_cart(request):
    if request.method == 'POST':
        try:
            # Parse JSON data from request
            data = json.loads(request.body)
            product_id = str(data.get('productId'))
            user_id = str(data.get('userId'))
            
            # Validate input
            if not product_id or not user_id:
                return JsonResponse({
                    'status': 'error',
                    'message': 'Both productId and userId are required'
                }, status=400)
            
            # Ensure carts directory exists
            carts_dir = os.path.join(settings.BASE_DIR, 'carts')
            os.makedirs(carts_dir, exist_ok=True)
            
            # Define cart file path
            cart_filename = f"{user_id}cart.json"
            cart_filepath = os.path.join(carts_dir, cart_filename)
            
            # Initialize cart data structure
            cart_data = {"cartaddedproducts": []}
            
            # If file exists, load its content
            if os.path.exists(cart_filepath):
                try:
                    with open(cart_filepath, 'r') as f:
                        cart_data = json.load(f)
                    # Ensure the data structure is correct
                    if "cartaddedproducts" not in cart_data:
                        cart_data["cartaddedproducts"] = []
                except json.JSONDecodeError:
                    # Handle corrupt JSON file
                    cart_data = {"cartaddedproducts": []}
            
            # Add product if not already in cart
            if product_id not in cart_data["cartaddedproducts"]:
                cart_data["cartaddedproducts"].append(product_id)
                
                # Save to file
                with open(cart_filepath, 'w') as f:
                    json.dump(cart_data, f, indent=4)
                
                return JsonResponse({
                    'status': 'success',
                    'message': f'Product {product_id} added to cart for user {user_id}',
                    'cart': cart_data
                })
            else:
                return JsonResponse({
                    'status': 'info',
                    'message': 'Product already in cart',
                    'cart': cart_data
                })
                
        except Exception as e:
            logger.error(f"Error in add_to_cart: {str(e)}")
            return JsonResponse({
                'status': 'error',
                'message': 'Internal server error'
            }, status=500)
    
    return JsonResponse({
        'status': 'error',
        'message': 'Only POST requests are allowed'
    }, status=405)


"""


from django.shortcuts import render
import json
import os
from django.http import JsonResponse
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

@csrf_exempt
def add_to_cart(request):
    if request.method == 'POST':
        try:
            # Parse JSON data from request
            data = json.loads(request.body)
            product_id = str(data.get('productId'))
            user_id = str(data.get('userId'))

            # Validate input
            if not product_id or not user_id:
                return JsonResponse({
                    'status': 'error',
                    'message': 'Both productId and userId are required'
                }, status=400)

            # Get current date and time
            now = datetime.now()
            date_added = now.strftime("%Y-%m-%d")
            time_added = now.strftime("%H:%M:%S")

            # Ensure carts directory exists
            carts_dir = os.path.join(settings.BASE_DIR, 'carts')
            os.makedirs(carts_dir, exist_ok=True)

            # Define cart file path
            cart_filename = f"{user_id}cart.json"
            cart_filepath = os.path.join(carts_dir, cart_filename)

            # Initialize cart data structure
            cart_data = {"cart_items": []}

            # If file exists, load its content
            if os.path.exists(cart_filepath):
                try:
                    with open(cart_filepath, 'r') as f:
                        cart_data = json.load(f)
                    # Ensure the data structure is correct
                    if "cart_items" not in cart_data:
                        cart_data["cart_items"] = []
                except json.JSONDecodeError:
                    # Handle corrupt JSON file
                    cart_data = {"cart_items": []}

            # Check if product already exists in cart
            product_exists = False
            for item in cart_data["cart_items"]:
                if item["productId"] == product_id:
                    product_exists = True
                    break

            if not product_exists:
                # Create new cart item with all required fields
                new_item = {
                    "productId": product_id,
                    "userId": user_id,
                    "timeaddedtocart": time_added,
                    "dateaddedtocart": date_added,
                    "status": "oncart"  # Initial status
                }

                cart_data["cart_items"].append(new_item)

                # Save to file
                with open(cart_filepath, 'w') as f:
                    json.dump(cart_data, f, indent=4)

                return JsonResponse({
                    'status': 'success',
                    'message': f'Product {product_id} added to cart for user {user_id}',
                    'cart': cart_data
                })
            else:
                return JsonResponse({
                    'status': 'info',
                    'message': 'Product already in cart',
                    'cart': cart_data
                })

        except Exception as e:
            logger.error(f"Error in add_to_cart: {str(e)}")
            return JsonResponse({
                'status': 'error',
                'message': 'Internal server error'
            }, status=500)

    return JsonResponse({
        'status': 'error',
        'message': 'Only POST requests are allowed'
    }, status=405)







@csrf_exempt
def fetch_cart_data(request):
    if request.method == 'POST':
        try:
            # Parse JSON data from request
            data = json.loads(request.body)
            user_id = str(data.get('userId'))

            # Validate input
            if not user_id:
                return JsonResponse({
                    'status': 'error',
                    'message': 'userId is required'
                }, status=400)

            # Define cart file path
            cart_filename = f"{user_id}cart.json"
            cart_filepath = os.path.join(settings.BASE_DIR, 'carts', cart_filename)

            # Initialize response data
            response_data = {
                'status': 'success',
                'total_products': 0,
                'cart_items': [],
                'html': ''
            }

            # If file exists, load its content
            if os.path.exists(cart_filepath):
                try:
                    with open(cart_filepath, 'r') as f:
                        cart_data = json.load(f)
                    
                    # Ensure the data structure is correct
                    if "cart_items" in cart_data:
                        response_data['total_products'] = len(cart_data["cart_items"])
                        response_data['cart_items'] = cart_data["cart_items"]
                        
                        # Generate HTML table
                        html = """
                        <table class="cart-table">
                            <thead>
                                <tr>
                                    <th>Product ID</th>
                                    <th>Date Added</th>
                                    <th>Time Added</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                        """
                        
                        for item in cart_data["cart_items"]:
                            html += f"""
                            <tr>
                                <td>{item.get('productId', '')}</td>
                                <td>{item.get('dateaddedtocart', '')}</td>
                                <td>{item.get('timeaddedtocart', '')}</td>
                                <td>{item.get('status', '')}</td>
                            </tr>
                            """
                        
                        html += """
                            </tbody>
                        </table>
                        """
                        
                        response_data['html'] = html
                        
                except json.JSONDecodeError:
                    # Handle corrupt JSON file
                    return JsonResponse({
                        'status': 'error',
                        'message': 'Cart data is corrupted'
                    }, status=500)

            return JsonResponse(response_data)

        except Exception as e:
            logger.error(f"Error in fetch_cart_data: {str(e)}")
            return JsonResponse({
                'status': 'error',
                'message': 'Internal server error'
            }, status=500)

    return JsonResponse({
        'status': 'error',
        'message': 'Only POST requests are allowed'
    }, status=405)





