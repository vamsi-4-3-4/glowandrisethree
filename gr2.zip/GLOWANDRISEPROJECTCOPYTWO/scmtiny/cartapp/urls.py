
from django.urls import path
from . import views

urlpatterns = [
    path('addtocart/', views.add_to_cart, name='add_to_cart'),
    # ... your other URLs
    path('fetch-cart-data/', views.fetch_cart_data, name='fetch_cart_data'),




]
