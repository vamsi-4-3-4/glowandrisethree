package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

// --- Global Configuration ---
const (
	// DataDir is the base directory where inventory files will be stored.
	// This should be set to the absolute path of your Django 'data' directory
	// if you want the Go app to share data with Django.
	// Example: "/home/u0_a378/G/scmtiny/data"
	DataDir = "data" // Keep "data" if you want a separate data directory for Go app
	// MasterDatasetPath is the path to the master_dataset.json file.
	MasterDatasetPath = "data/master_dataset.json"
)

// --- Initialization ---

// init is a special Go function that runs automatically once when the package is initialized.
func init() {
	// Ensure the 'data' directory exists.
	if err := os.MkdirAll(DataDir, 0755); err != nil {
		log.Fatalf("Failed to create data directory %s: %v", DataDir, err)
	}
	// Initialize the master dataset file.
	initializeMasterDataset()
}

// --- Data Structures (Go structs) ---

// Vegetable represents a single vegetable entry in the master dataset.
type Vegetable struct {
	Vegetable   string   `json:"vegetable"`
	SubVariants []string `json:"sub_variants"`
}

// InventoryItem represents a sub-variant's quantity in the inventory.
type InventoryItem struct {
	Quantity int `json:"quantity"`
}

// StoreInventory represents the complete inventory for a single store at a specific timestamp.
type StoreInventory struct {
	StoreID      string                             `json:"StoreId"`
	StoreName    string                             `json:"StoreName"`
	StoreAddress string                             `json:"StoreAddress"`
	Timestamp    time.Time                          `json:"timestamp"`
	Vegetables   map[string]map[string]InventoryItem `json:"vegetables"`
}

// IncomingVegetableDetails handles the flexible quantity field from the frontend.
type IncomingVegetableDetails struct {
	Quantity interface{} `json:"quantity"` // Can be int or a map like {"quantity": int}
}

// IncomingPayload is the structure for POST request bodies.
type IncomingPayload struct {
	StoreID            string                               `json:"StoreId"`
	StoreName          string                               `json:"StoreName"`
	StoreAddress       string                               `json:"StoreAddress"`
	IncomingVegetables map[string]map[string]IncomingVegetableDetails `json:"vegetables"`
}

// ReportEntry is a single entry in the sales and quantity report.
type ReportEntry struct {
	Vegetable      string `json:"vegetable"`
	SubVariant     string `json:"sub_variant"`
	DateTime       string `json:"date_time"`
	QuantityChange int    `json:"quantity_change"`
	TotalQuantity  int    `json:"total_quantity"`
}

// --- Helper Functions ---

// initializeMasterDataset creates the master_dataset.json file if it doesn't exist.
func initializeMasterDataset() {
	if _, err := os.Stat(MasterDatasetPath); os.IsNotExist(err) {
		vegetablesData := []Vegetable{
			{Vegetable: "Potato", SubVariants: []string{"Kufri Bahar", "Kufri Jyoti", "Kufri Pukhraj", "Lady Rosetta", "Desi Aloo"}},
			{Vegetable: "Tomato", SubVariants: []string{"Arka Rakshak", "Pusa Ruby", "Cherry Tomato", "Hybrid Tomato", "Local Desi Tamatar"}},
			{Vegetable: "Onion", SubVariants: []string{"Red Onion", "White Onion", "Shallots (Madras Vengayam)", "Spring Onion"}},
			{Vegetable: "Brinjal (Eggplant)", SubVariants: []string{"Long", "Round", "Green", "White", "Bharta Baingan", "Small Brinjal"}},
			{Vegetable: "Okra (Bhindi)", SubVariants: []string{"Arka Anamika", "Pusa Sawani", "Hybrid Bhindi"}},
			{Vegetable: "Cauliflower", SubVariants: []string{"Early Snowball", "Pusa Snowball", "Hybrid Gobi"}},
			{Vegetable: "Cabbage", SubVariants: []string{"Golden Acre", "Pride of India", "Red Cabbage"}},
			{Vegetable: "Carrot", SubVariants: []string{"Red Desi Carrot", "Orange Hybrid", "Black Carrot"}},
			{Vegetable: "Beetroot", SubVariants: []string{"Detroit Dark Red", "Crimson Globe"}},
			{Vegetable: "Radish", SubVariants: []string{"Pusa Chetki", "Pusa Desi", "Japanese White", "Red Radish"}},
			{Vegetable: "Chilli", SubVariants: []string{"Green Chillies", "Red Chillies", "Bird's Eye Chilli", "Bhut Jolokia", "Bell Pepper"}},
			{Vegetable: "Spinach", SubVariants: []string{"Palak", "Amarnath", "Fenugreek (Methi)"}},
			{Vegetable: "Capsicum (Bell Pepper)", SubVariants: []string{"Green Capsicum", "Red Capsicum", "Yellow Capsicum"}},
			{Vegetable: "Ginger", SubVariants: []string{"Fresh Ginger", "Dried Ginger"}},
			{Vegetable: "Garlic", SubVariants: []string{"Local Garlic", "Himalayan Garlic", "Peeled Garlic"}},
			{Vegetable: "Mushroom", SubVariants: []string{"Button Mushroom", "Oyster Mushroom", "Portobello Mushroom", "Shiitake Mushroom"}},
			{Vegetable: "Pumpkin", SubVariants: []string{"Red Pumpkin", "White Pumpkin", "Long Pumpkin"}},
			{Vegetable: "Drumstick", SubVariants: []string{"Fresh Drumstick", "Dried Drumstick"}},
			{Vegetable: "Lemon", SubVariants: []string{"Lime (Small Lemon)", "Sweet Lime (Mosambi)"}},
			{Vegetable: "Cucumber", SubVariants: []string{"Local Cucumber", "English Cucumber", "Kakdi"}},
			{Vegetable: "Bitter Gourd (Karela)", SubVariants: []string{"Small Karela", "Big Karela"}},
			{Vegetable: "Ridge Gourd (Turai)", SubVariants: []string{"Smooth Turai", "Ridged Turai"}},
			{Vegetable: "Bottle Gourd (Lauki)", SubVariants: []string{"Long Bottle Gourd", "Round Bottle Gourd"}},
			{Vegetable: "Sweet Potato", SubVariants: []string{"Red Sweet Potato", "White Sweet Potato"}},
			{Vegetable: "Cluster Beans (Gavar)", SubVariants: []string{"Fresh Gavar"}},
		}

		data, err := json.MarshalIndent(vegetablesData, "", "    ")
		if err != nil {
			log.Printf("Error marshalling master dataset: %v", err)
			return
		}
		if err := ioutil.WriteFile(MasterDatasetPath, data, 0644); err != nil {
			log.Printf("Failed to write master dataset file: %v", err)
			return
		}
		log.Printf("Master dataset initialized at %s", MasterDatasetPath)
	} else {
		log.Printf("Master dataset already exists at %s", MasterDatasetPath)
	}
}

// getLatestInventoryFile reads the latest inventory file for a given store ID.
// It returns the file path, the parsed data, and any error. If no file is found, data is nil.
func getLatestInventoryFile(storeID string) (string, *StoreInventory, error) {
	searchPattern := filepath.Join(DataDir, fmt.Sprintf("%s_*_veg.json", storeID))
	files, err := filepath.Glob(searchPattern)
	if err != nil {
		return "", nil, fmt.Errorf("error globbing files: %w", err)
	}

	if len(files) == 0 {
		return "", nil, nil // No files found for this store ID
	}

	// Sort files by timestamp in their name to get the latest one.
	sort.Slice(files, func(i, j int) bool {
		nameI := filepath.Base(files[i])
		nameJ := filepath.Base(files[j])

		partsI := strings.Split(nameI, "_")
		partsJ := strings.Split(nameJ, "_")

		// Ensure filename parts exist for timestamp extraction.
		if len(partsI) < 3 || len(partsJ) < 3 {
			// Fallback to simple string comparison if naming convention is unexpected.
			return nameI < nameJ
		}
		// Extract YYYYMMDD_HHMMSS from filename.
		tsI := partsI[1] + "_" + strings.Split(partsI[2], ".")[0]
		tsJ := partsJ[1] + "_" + strings.Split(partsJ[2], ".")[0]

		// Parse timestamps for accurate comparison.
		t1, err1 := time.Parse("20060102_150405", tsI)
		t2, err2 := time.Parse("20060102_150405", tsJ)

		if err1 != nil || err2 != nil {
			log.Printf("Warning: Error parsing timestamp from filename for sorting. Fallback to string comparison. File1: %s, Error1: %v, File2: %s, Error2: %v", nameI, err1, nameJ, err2)
			return nameI < nameJ // Fallback for unparsable timestamps
		}
		return t1.Before(t2) // Sort in ascending order, so the last one is the latest.
	})

	latestFilePath := files[len(files)-1]
	dataBytes, err := ioutil.ReadFile(latestFilePath)
	if err != nil {
		return "", nil, fmt.Errorf("error reading latest file %s: %w", latestFilePath, err)
	}

	var inventory StoreInventory
	if err := json.Unmarshal(dataBytes, &inventory); err != nil {
		return "", nil, fmt.Errorf("error unmarshalling latest file %s: %w", latestFilePath, err)
	}

	return latestFilePath, &inventory, nil
}

// initializeInventoryFromMaster reads the master dataset and creates an initial inventory with 0 quantities.
func initializeInventoryFromMaster() (map[string]map[string]InventoryItem, error) {
	masterDataBytes, err := ioutil.ReadFile(MasterDatasetPath)
	if err != nil {
		return nil, fmt.Errorf("error reading master dataset file %s: %w", MasterDatasetPath, err)
	}

	var masterData []Vegetable
	if err := json.Unmarshal(masterDataBytes, &masterData); err != nil {
		return nil, fmt.Errorf("error unmarshalling master dataset file %s: %w", MasterDatasetPath, err)
	}

	initialInventory := make(map[string]map[string]InventoryItem)
	for _, vegItem := range masterData {
		initialInventory[vegItem.Vegetable] = make(map[string]InventoryItem)
		for _, subVariant := range vegItem.SubVariants {
			initialInventory[vegItem.Vegetable][subVariant] = InventoryItem{Quantity: 0}
		}
	}
	return initialInventory, nil
}

// writeJSONResponse is a helper to write JSON responses consistently.
func writeJSONResponse(w http.ResponseWriter, status int, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	if err := json.NewEncoder(w).Encode(data); err != nil {
		log.Printf("Error writing JSON response: %v", err)
		// Fallback to plain text error if JSON encoding fails
		http.Error(w, "Internal server error: Could not encode JSON response", http.StatusInternalServerError)
	}
}

// writeErrorResponse is a helper to write JSON error responses.
func writeErrorResponse(w http.ResponseWriter, status int, message string, err error) {
	log.Printf("Error %d: %s; Details: %v", status, message, err)
	writeJSONResponse(w, status, map[string]string{"message": message})
}

// setCORSHeaders sets the necessary CORS headers for cross-origin requests.
func setCORSHeaders(w http.ResponseWriter, r *http.Request) {
	// For development, allow all origins. In production, restrict to your frontend's domain.
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With")

	// Handle preflight requests
	if r.Method == http.MethodOptions {
		w.WriteHeader(http.StatusOK)
		return
	}
}

// --- HTTP Handlers ---

// handleGetVegetableProducts handles both POST (update) and GET (retrieve) requests for inventory.
func handleGetVegetableProducts(w http.ResponseWriter, r *http.Request) {
	// Set CORS headers for all requests to this handler
	setCORSHeaders(w, r)
	if r.Method == http.MethodOptions {
		return // Preflight handled by setCORSHeaders
	}

	switch r.Method {
	case http.MethodPost:
		handleInventoryPost(w, r)
	case http.MethodGet:
		handleInventoryGet(w, r)
	default:
		writeErrorResponse(w, http.StatusMethodNotAllowed, "Method not allowed", nil)
	}
}

// handleInventoryPost processes POST requests to update vegetable inventory.
func handleInventoryPost(w http.ResponseWriter, r *http.Request) {
	var payload IncomingPayload
	if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
		writeErrorResponse(w, http.StatusBadRequest, "Invalid JSON in request body", err)
		return
	}

	if payload.StoreID == "" {
		writeErrorResponse(w, http.StatusBadRequest, "StoreId is required", nil)
		return
	}

	currentInventory := make(map[string]map[string]InventoryItem)

	// Attempt to load the latest inventory for the store.
	_, existingInventory, err := getLatestInventoryFile(payload.StoreID)
	if err != nil {
		writeErrorResponse(w, http.StatusInternalServerError, fmt.Sprintf("Error processing existing inventory: %v", err), err)
		return
	}
	if existingInventory != nil {
		currentInventory = existingInventory.Vegetables
		log.Printf("Loaded existing inventory for StoreId %s from latest file.", payload.StoreID)
	} else {
		// If no existing file, initialize from the master dataset.
		initial, initErr := initializeInventoryFromMaster()
		if initErr != nil {
			writeErrorResponse(w, http.StatusInternalServerError, fmt.Sprintf("Error initializing inventory from master dataset: %v", initErr), initErr)
			return
		}
		currentInventory = initial
		log.Printf("Initialized inventory from master dataset for StoreId %s.", payload.StoreID)
	}

	// Update quantities based on the incoming data.
	for vegName, subVariantsData := range payload.IncomingVegetables {
		if _, ok := currentInventory[vegName]; !ok {
			currentInventory[vegName] = make(map[string]InventoryItem)
		}
		for subVariant, details := range subVariantsData {
			incomingQuantity := 0
			// Determine the quantity value, supporting both int and {"quantity": int} formats.
			switch v := details.Quantity.(type) {
			case float64: // JSON numbers are decoded as float64 by default in Go's json package.
				incomingQuantity = int(v)
			case int: // If the quantity was already an integer.
				incomingQuantity = v
			case map[string]interface{}: // If it's a nested map.
				if q, ok := v["quantity"].(float64); ok {
					incomingQuantity = int(q)
				} else {
					log.Printf("Warning: Unexpected data type for quantity in map for %s - %s: %v. Defaulting to 0.", vegName, subVariant, v["quantity"])
				}
			default:
				log.Printf("Warning: Unexpected data type for quantity of %s - %s: %v. Defaulting to 0.", vegName, subVariant, v)
			}

			if _, ok := currentInventory[vegName][subVariant]; !ok {
				currentInventory[vegName][subVariant] = InventoryItem{Quantity: 0}
			}
			// Update the quantity by adding the incoming amount.
			item := currentInventory[vegName][subVariant]
			item.Quantity += incomingQuantity
			currentInventory[vegName][subVariant] = item
		}
	}

	// Prepare and save the updated inventory to a new JSON file.
	now := time.Now()
	timestampStr := now.Format("20060102_150405") // YYYYMMDD_HHMMSS format.
	fileName := fmt.Sprintf("%s_%s_veg.json", payload.StoreID, timestampStr)
	filePath := filepath.Join(DataDir, fileName)

	dataToSave := StoreInventory{
		StoreID:      payload.StoreID,
		StoreName:    payload.StoreName,
		StoreAddress: payload.StoreAddress,
		Timestamp:    now,
		Vegetables:   currentInventory,
	}

	jsonData, err := json.MarshalIndent(dataToSave, "", "    ")
	if err != nil {
		writeErrorResponse(w, http.StatusInternalServerError, "Error processing data for saving", err)
		return
	}

	if err := ioutil.WriteFile(filePath, jsonData, 0644); err != nil {
		writeErrorResponse(w, http.StatusInternalServerError, fmt.Sprintf("Error saving inventory data to %s", fileName), err)
		return
	}

	log.Printf("Inventory for StoreId %s updated and saved to %s", payload.StoreID, fileName)
	response := map[string]interface{}{
		"message":                    fmt.Sprintf("Inventory for StoreId %s updated and saved to %s", payload.StoreID, fileName),
		"current_inventory_snapshot": dataToSave,
	}
	writeJSONResponse(w, http.StatusOK, response)
}

// handleInventoryGet processes GET requests to retrieve the latest vegetable inventory.
func handleInventoryGet(w http.ResponseWriter, r *http.Request) {
	storeID := r.URL.Query().Get("store_id")

	if storeID == "" {
		writeErrorResponse(w, http.StatusBadRequest, "store_id is required for GET request", nil)
		return
	}

	_, currentData, err := getLatestInventoryFile(storeID)
	if err != nil {
		writeErrorResponse(w, http.StatusInternalServerError, fmt.Sprintf("Error reading latest inventory file: %v", err), err)
		return
	}

	if currentData != nil {
		log.Printf("Retrieved latest inventory for StoreId %s.", storeID)
		response := map[string]interface{}{
			"message": fmt.Sprintf("Latest inventory for StoreId %s.", storeID),
			"data":    currentData,
		}
		writeJSONResponse(w, http.StatusOK, response)
	} else {
		// If no existing file, initialize from master dataset with 0 quantities and create a new file.
		initialVegetables, initErr := initializeInventoryFromMaster()
		if initErr != nil {
			writeErrorResponse(w, http.StatusInternalServerError, fmt.Sprintf("Error initializing inventory from master dataset: %v", initErr), initErr)
			return
		}

		now := time.Now()
		timestampStr := now.Format("20060102_150405")
		fileName := fmt.Sprintf("%s_%s_veg.json", storeID, timestampStr)
		filePath := filepath.Join(DataDir, fileName)

		initialData := StoreInventory{
			StoreID:      storeID,
			StoreName:    "Not Set",
			StoreAddress: "Not Set",
			Timestamp:    now,
			Vegetables:   initialVegetables,
		}

		jsonData, marshalErr := json.MarshalIndent(initialData, "", "    ")
		if marshalErr != nil {
			writeErrorResponse(w, http.StatusInternalServerError, "Error processing initial data for saving", marshalErr)
			return
		}

		if writeErr := ioutil.WriteFile(filePath, jsonData, 0644); writeErr != nil {
			writeErrorResponse(w, http.StatusInternalServerError, fmt.Sprintf("Error creating initial inventory file %s", fileName), writeErr)
			return
		}

		log.Printf("File %s created and initialized with empty data for StoreId %s.", fileName, storeID)
		response := map[string]interface{}{
			"message": fmt.Sprintf("File %s created and initialized with empty data.", fileName),
			"data":    initialData,
		}
		writeJSONResponse(w, http.StatusCreated, response)
	}
}

// handleSalesAndQuantityDetails handles GET requests for sales and quantity details report.
func handleSalesAndQuantityDetails(w http.ResponseWriter, r *http.Request) {
	// Set CORS headers for all requests to this handler
	setCORSHeaders(w, r)
	if r.Method == http.MethodOptions {
		return // Preflight handled by setCORSHeaders
	}

	if r.Method != http.MethodGet {
		writeErrorResponse(w, http.StatusMethodNotAllowed, "Method not allowed", nil)
		return
	}

	storeID := r.URL.Query().Get("store_id")

	if storeID == "" {
		writeErrorResponse(w, http.StatusBadRequest, "store_id is required for sales and quantity details", nil)
		return
	}

	searchPattern := filepath.Join(DataDir, fmt.Sprintf("%s_*_veg.json", storeID))
	storeFiles, err := filepath.Glob(searchPattern)
	if err != nil {
		writeErrorResponse(w, http.StatusInternalServerError, "Error retrieving store data", err)
		return
	}

	if len(storeFiles) == 0 {
		writeErrorResponse(w, http.StatusNotFound, fmt.Sprintf("No inventory data found for StoreId %s", storeID), nil)
		return
	}

	// Sort files by their timestamp in the filename to ensure correct chronological processing.
	sort.Slice(storeFiles, func(i, j int) bool {
		nameI := filepath.Base(storeFiles[i])
		nameJ := filepath.Base(storeFiles[j])

		partsI := strings.Split(nameI, "_")
		partsJ := strings.Split(nameJ, "_")

		if len(partsI) < 3 || len(partsJ) < 3 {
			return nameI < nameJ // Fallback if naming convention is unexpected
		}
		tsI := partsI[1] + "_" + strings.Split(partsI[2], ".")[0]
		tsJ := partsJ[1] + "_" + strings.Split(partsJ[2], ".")[0]

		t1, err1 := time.Parse("20060102_150405", tsI)
		t2, err2 := time.Parse("20060102_150405", tsJ)

		if err1 != nil || err2 != nil {
			log.Printf("Warning: Error parsing timestamp from filename for sales report. Fallback to string comparison. File1: %s, Error1: %v, File2: %s, Error2: %v", nameI, err1, nameJ, err2)
			return nameI < nameJ
		}
		return t1.Before(t2)
	})

	reportData := make(map[string]map[string][]ReportEntry) // { vegetable_name: { sub_variant: [] } }
	previousInventory := make(map[string]map[string]InventoryItem)

	for _, filePath := range storeFiles {
		dataBytes, err := ioutil.ReadFile(filePath)
		if err != nil {
			log.Printf("Error reading file %s for sales report: %v", filePath, err)
			continue // Skip unreadable files
		}

		var data StoreInventory
		if err := json.Unmarshal(dataBytes, &data); err != nil {
			log.Printf("Warning: Corrupted JSON file found for sales report: %s, Error: %v", filePath, err)
			continue // Skip corrupted JSON files
		}

		timestampObj := data.Timestamp
		// Fallback for older files that might not have the "timestamp" field or it's invalid.
		if timestampObj.IsZero() {
			fileTimestampPart := strings.Split(filepath.Base(filePath), "_")
			if len(fileTimestampPart) >= 3 {
				tsStr := fileTimestampPart[1] + "_" + strings.Split(fileTimestampPart[2], ".")[0]
				if t, err := time.Parse("20060102_150405", tsStr); err == nil {
					timestampObj = t
				} else {
					log.Printf("Warning: Could not parse timestamp from filename %s: %v", filePath, err)
				}
			}
		}

		currentVegetables := data.Vegetables

		for vegName, subVariantsData := range currentVegetables {
			if _, ok := reportData[vegName]; !ok {
				reportData[vegName] = make(map[string][]ReportEntry)
			}

			for subVariant, details := range subVariantsData {
				currentQuantity := details.Quantity

				previousQuantity := 0
				if prevVeg, ok := previousInventory[vegName]; ok {
					if prevSub, ok := prevVeg[subVariant]; ok {
						previousQuantity = prevSub.Quantity
					}
				}
				quantityAdded := currentQuantity - previousQuantity

				if _, ok := reportData[vegName][subVariant]; !ok {
					reportData[vegName][subVariant] = []ReportEntry{}
				}

				reportEntry := ReportEntry{
					DateTime:       timestampObj.Format("02/01/2006 03:04PM"), // dd/mm/yyyy hh:mmAM/PM
					QuantityChange: quantityAdded,
					TotalQuantity:  currentQuantity,
				}
				reportData[vegName][subVariant] = append(reportData[vegName][subVariant], reportEntry)
			}
		}
		// Update previous inventory for the next iteration.
		previousInventory = currentVegetables
	}

	// Flatten the report data for easier display in a table format.
	var finalReport []ReportEntry
	for vegName, subVariants := range reportData {
		for subVariant, entries := range subVariants {
			for _, entry := range entries {
				entry.Vegetable = vegName
				entry.SubVariant = subVariant
				finalReport = append(finalReport, entry)
			}
		}
	}

	// Sort the final report by date and time to present chronologically.
	sort.Slice(finalReport, func(i, j int) bool {
		t1, err1 := time.Parse("02/01/2006 03:04PM", finalReport[i].DateTime)
		t2, err2 := time.Parse("02/01/2006 03:04PM", finalReport[j].DateTime)
		if err1 != nil || err2 != nil {
			log.Printf("Warning: Error parsing datetime from report entry for final sort. Fallback to string comparison. Entry1: %s, Error1: %v, Entry2: %s, Error2: %v", finalReport[i].DateTime, err1, finalReport[j].DateTime, err2)
			return finalReport[i].DateTime < finalReport[j].DateTime
		}
		return t1.Before(t2)
	})

	response := map[string]interface{}{
		"store_id": storeID,
		"report":   finalReport,
	}
	writeJSONResponse(w, http.StatusOK, response)
}

// --- Main Function to Start the HTTP Server ---
func main() {
	// Root endpoint (optional, similar to Django's `index` view).
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		// Set CORS headers for the root path too, if this path might be accessed by frontend.
		setCORSHeaders(w, r)
		if r.Method == http.MethodOptions {
			return
		}
		fmt.Fprintf(w, "Welcome to the Vegetable Inventory API (GoLang Version)!")
	})

	// Register the handler for inventory operations.
	// We use a single handler `handleGetVegetableProducts` to route POST/GET requests.
	http.HandleFunc("/get_vegetable_products/", handleGetVegetableProducts)

	// Register the handler for sales and quantity details.
	http.HandleFunc("/sales_and_quantity_details/", handleSalesAndQuantityDetails)

	fmt.Println("Server starting on :8001...")
	log.Fatal(http.ListenAndServe(":8001", nil))
}
