module vegetable-api-go

go 1.24.1
