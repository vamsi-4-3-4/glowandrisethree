from django.apps import AppConfig


class ScmtinyappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'scmtinyapp'
