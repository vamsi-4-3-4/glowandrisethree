from django.shortcuts import render






def index(request):
	return render(request,"index.html")





import json
from django.http import JsonResponse
import os
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

def serve_overall_inventory(request):
    try:
        # Load the inventory data file
        inventory_path = os.path.join(settings.BASE_DIR, 'overallInventoryUpdateHistory.json')

        # Verify file exists
        if not os.path.exists(inventory_path):
            error_msg = "Inventory data file not found"
            logger.error(error_msg)
            return JsonResponse({'error': error_msg}, status=500)

        # Load data
        with open(inventory_path, 'r', encoding='utf-8') as f:
            inventory_data = json.load(f)

        # Get query parameters
        product_id = request.GET.get('productId')
        variant_id = request.GET.get('variantId')

        if not product_id or not variant_id:
            return JsonResponse({
                'error': 'Both productId and variantId parameters are required'
            }, status=400)

        logger.info(f"Searching for productId: {product_id}, variantId: {variant_id}")

        total_units_available = 0
        prices = []
        found_variants = []

        # Search through all sellers and their products
        for seller in inventory_data:
            for product in seller['products']:
                # Check both regular productId and combined productId_variantId format
                if (product['productId'] == product_id or
                    product['productId'].startswith(f"{product_id}_")):

                    for variant in product['productVariants']:
                        if variant['variantId'] == variant_id:
                            # Collect inventory data from all sellers
                            found_variants.append({
                                'sellerId': seller['sellerId'],
                                'sellerName': seller['sellerName'],
                                'unitsAvailable': variant['variantUnitsAvailable'],
                                'price': variant['variantPrice']
                            })
                            
                            # Sum up available units
                            total_units_available += variant['variantUnitsAvailable']
                            
                            # Collect non-zero prices for finding the minimum
                            if variant['variantPrice'] > 0:
                                prices.append(variant['variantPrice'])

        if not found_variants:
            logger.warning(f"No match found for productId: {product_id}, variantId: {variant_id}")
            return JsonResponse({
                'error': 'Product variant not found',
                'productId': product_id,
                'variantId': variant_id,
                'status': 'error'
            }, status=404)

        # Determine the lowest available price (if any sellers have set a price)
        lowest_price = min(prices) if prices else 0

        # Prepare response with aggregated data
        response_data = {
            'productId': product_id,
            'variantId': variant_id,
            'unitsAvailable': total_units_available,
            'price': lowest_price,
            'sellerCount': len(found_variants),
            'status': 'success',
            'sellers': found_variants  # Optional: include detailed seller info
        }

        return JsonResponse(response_data)

    except json.JSONDecodeError as e:
        error_msg = f"Error decoding JSON: {str(e)}"
        logger.error(error_msg)
        return JsonResponse({
            'error': 'Invalid inventory data format',
            'details': error_msg,
            'status': 'error'
        }, status=500)

    except Exception as e:
        error_msg = f"Unexpected error: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return JsonResponse({
            'error': 'Internal server error',
            'details': error_msg,
            'status': 'error'
        }, status=500)


import json
import os
from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render

def serve_leafy_vegetables_inventory(request):
    # Path to the JSON file
    json_file_path = os.path.join(settings.BASE_DIR, 'overallLeafyVegetables.json')
    
    try:
        with open(json_file_path, 'r') as f:
            inventory_data = json.load(f)
        return JsonResponse(inventory_data, safe=False)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)






import json
import os
from django.shortcuts import render
from django.http import JsonResponse
from django.conf import settings

def serve_vegetables_template(request):
    """
    Renders the HTML template and serves the vegetable product data.
    """
    # Construct the absolute path to your JSON file
    # Assuming 'data' directory is sibling to 'views.py'
    json_file_path = os.path.join(settings.BASE_DIR, 'leafyVegetables.json')

    try:
        with open(json_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return JsonResponse(data, safe=False) # safe=False is needed when returning a list directly
    except FileNotFoundError:
        return JsonResponse({"error": "Data file not found."}, status=404)
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON data in file."}, status=500)
    except Exception as e:
        return JsonResponse({"error": f"An unexpected error occurred: {str(e)}"}, status=500)











import os
import json
from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime

# Helper function to get the correct seller inventory file path
def get_seller_inventory_file_path(seller_id):
    return os.path.join(settings.BASE_DIR, f'seller_{seller_id}_inventory.json')

@csrf_exempt
def update_inventory(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)

            # Validate incoming data for essential keys
            required_keys = ['sellerId', 'sellerName', 'sellerBranchName', 'sellerBranchAddress',
                             'sellerWarehouseName', 'sellerWarehouseAddress', 'inventoryUpdates']
            if not all(key in data for key in required_keys):
                return JsonResponse({'success': False, 'message': 'Missing essential data in request.'}, status=400)

            # Get current date and time
            current_date = datetime.now().strftime("%Y-%m-%d")
            current_time = datetime.now().strftime("%H:%M:%S")

            # Update all JSON files
            update_overall_leafy_vegetables(data, current_date, current_time)
            update_seller_inventory(data, current_date, current_time) # Renamed for clarity and to reflect new logic
            update_overall_inventory_history(data, current_date, current_time)
            update_seller_inventory_history(data, current_date, current_time)

            return JsonResponse({'success': True, 'message': 'Inventory updated successfully'})
        except json.JSONDecodeError:
            return JsonResponse({'success': False, 'message': 'Invalid JSON format in request body.'}, status=400)
        except Exception as e:
            return JsonResponse({'success': False, 'message': str(e)}, status=500)
    return JsonResponse({'success': False, 'message': 'Invalid request method'}, status=405)

def update_overall_leafy_vegetables(data, current_date, current_time):
    """Update overallLeafyVegetables.json"""
    json_file_path = os.path.join(settings.BASE_DIR, 'overallLeafyVegetables.json')

    try:
        with open(json_file_path, 'r+') as f:
            leafy_vegetables = json.load(f)

            for product_id, update_data in data['inventoryUpdates'].items():
                # Find the product in the list
                product = next((p for p in leafy_vegetables if p['productId'] == product_id), None)
                if product:
                    # Find the variant
                    variant = next((v for v in product['productVariants'] if v['variantId'] == update_data['variantId']), None)
                    if variant:
                        # Update units available
                        variant['variantUnitsAvailable'] += update_data.get('added', 0) - update_data.get('removed', 0)
                        # Update price if provided in the update data
                        if 'price' in update_data:
                            variant['variantUnitPrice'] = update_data['price']

                        # Add inventory update record
                        update_record = {
                            "variantInventoryUpdateId": f"inv-{len(variant['variantInventoryUpdates']) + 1}-{variant['variantName'].lower().replace(' ', '-')}-{current_date.replace('-', '')}",
                            "variantInventoryUpdatedDate": current_date,
                            "variantInventoryUpdatedTime": current_time,
                            "variantInventoryQuantityAdded": update_data.get('added', 0),
                            "variantInventoryQuantityRemoved": update_data.get('removed', 0),
                            "variantInventoryPriceAdded": update_data.get('price', variant.get('variantUnitPrice', 0)) # Use current price if 'price' not provided
                        }
                        variant['variantInventoryUpdates'].append(update_record)
                    else:
                        print(f"Warning: Variant with ID {update_data['variantId']} not found for product {product_id} in overallLeafyVegetables.json")
                else:
                    print(f"Warning: Product with ID {product_id} not found in overallLeafyVegetables.json")

            # Write back to file
            f.seek(0)
            json.dump(leafy_vegetables, f, indent=4)
            f.truncate()
    except FileNotFoundError:
        print(f"Error: {json_file_path} not found. Please ensure the file exists and is correctly structured.")
    except Exception as e:
        print(f"Error updating overallLeafyVegetables.json: {e}")


def update_seller_inventory(data, current_date, current_time):
    """Update seller_{sellerId}_inventory.json or create if not exists."""
    seller_id = data['sellerId']
    json_file_path = get_seller_inventory_file_path(seller_id)

    seller_inventory = {}
    if os.path.exists(json_file_path):
        with open(json_file_path, 'r+') as f:
            try:
                seller_inventory = json.load(f)
            except json.JSONDecodeError:
                # If file is empty or corrupted, reinitialize
                seller_inventory = {}
    
    # Update seller info
    seller_inventory['sellerId'] = data['sellerId']
    seller_inventory['sellerName'] = data['sellerName']
    seller_inventory['sellerBranchName'] = data['sellerBranchName']
    seller_inventory['sellerBranchAddress'] = data['sellerBranchAddress']
    seller_inventory['sellerWarehouseName'] = data['sellerWarehouseName']
    seller_inventory['sellerWarehouseAddress'] = data['sellerWarehouseAddress']

    if 'products' not in seller_inventory:
        seller_inventory['products'] = []

    # Update inventory quantities
    for product_id, update_data in data['inventoryUpdates'].items():
        product_found_in_seller_inventory = False
        for product in seller_inventory['products']:
            if product['productId'] == product_id:
                variant_found_in_seller_product = False
                for variant in product['productVariants']:
                    if variant['variantId'] == update_data['variantId']:
                        variant['variantUnitsAvailable'] += update_data.get('added', 0) - update_data.get('removed', 0)
                        if 'price' in update_data:
                            variant['variantPrice'] = update_data['price']
                        variant_found_in_seller_product = True
                        break
                if not variant_found_in_seller_product:
                    # Add new variant to existing product
                    product['productVariants'].append({
                        "variantId": update_data['variantId'],
                        "variantName": update_data['variantName'],
                        "variantImage": update_data.get('variantImage', ""),
                        "variantUnitsAvailable": update_data.get('added', 0) - update_data.get('removed', 0),
                        "variantPrice": update_data.get('price', 0)
                    })
                product_found_in_seller_inventory = True
                break
        
        if not product_found_in_seller_inventory:
            # Add new product and its variant to seller inventory
            seller_inventory['products'].append({
                "productId": product_id,
                "productName": update_data['productName'],
                "productImage": update_data.get('productImage', ""),
                "productVariants": [
                    {
                        "variantId": update_data['variantId'],
                        "variantName": update_data['variantName'],
                        "variantImage": update_data.get('variantImage', ""),
                        "variantUnitsAvailable": update_data.get('added', 0) - update_data.get('removed', 0),
                        "variantPrice": update_data.get('price', 0)
                    }
                ]
            })

    # Write back to file (or create if not exists)
    with open(json_file_path, 'w') as f: # Use 'w' to overwrite or create
        json.dump(seller_inventory, f, indent=4)


def update_overall_inventory_history(data, current_date, current_time):
    """Update overallInventoryUpdateHistory.json"""
    json_file_path = os.path.join(settings.BASE_DIR, 'overallInventoryUpdateHistory.json')

    inventory_history = []
    if os.path.exists(json_file_path):
        with open(json_file_path, 'r+') as f:
            try:
                inventory_history = json.load(f)
            except json.JSONDecodeError:
                # If file is empty or corrupted, start with an empty list
                inventory_history = []
    
    # Find or create seller entry
    seller = next((s for s in inventory_history if s['sellerId'] == data['sellerId']), None)
    if not seller:
        seller = {
            "sellerId": data['sellerId'],
            "sellerName": data['sellerName'],
            "sellerBranchName": data['sellerBranchName'],
            "sellerBranchAddress": data['sellerBranchAddress'],
            "sellerWarehouseName": data['sellerWarehouseName'],
            "sellerWarehouseAddress": data['sellerWarehouseAddress'],
            "products": []
        }
        inventory_history.append(seller)
    else:
        # Update seller details in history if they have changed
        seller['sellerName'] = data['sellerName']
        seller['sellerBranchName'] = data['sellerBranchName']
        seller['sellerBranchAddress'] = data['sellerBranchAddress']
        seller['sellerWarehouseName'] = data['sellerWarehouseName']
        seller['sellerWarehouseAddress'] = data['sellerWarehouseAddress']


    # Update products
    for product_id, update_data in data['inventoryUpdates'].items():
        # Find or create product entry
        product = next((p for p in seller['products'] if p['productId'] == product_id), None)
        if not product:
            product = {
                "productId": product_id,
                "productName": update_data['productName'],
                "productImage": update_data.get('productImage', ""),
                "productVariants": []
            }
            seller['products'].append(product)

        # Find or create variant entry
        variant = next((v for v in product['productVariants'] if v['variantId'] == update_data['variantId']), None)
        if not variant:
            variant = {
                "variantId": update_data['variantId'],
                "variantName": update_data['variantName'],
                "variantImage": update_data.get('variantImage', ""),
                "variantUnitsAvailable": 0, # This will be updated by the sum of added/removed in its own history
                "variantPrice": update_data.get('price', 0),
                "variantInventoryUpdates": []
            }
            product['productVariants'].append(variant)

        # Update units available based on current update
        variant['variantUnitsAvailable'] += update_data.get('added', 0) - update_data.get('removed', 0)
        
        # Add inventory update record
        update_record = {
            "variantInventoryUpdateId": f"inv-{data['sellerId']}-{variant['variantName'].lower().replace(' ', '-')}-{len(variant['variantInventoryUpdates']) + 1}-{current_date.replace('-', '')}",
            "variantInventoryUpdatedDate": current_date,
            "variantInventoryUpdatedTime": current_time,
            "variantInventoryQuantityAdded": update_data.get('added', 0),
            "variantInventoryQuantityRemoved": update_data.get('removed', 0),
            "variantInventoryPriceAdded": update_data.get('price', variant.get('variantPrice', 0))
        }
        variant['variantInventoryUpdates'].append(update_record)

    # Write back to file
    with open(json_file_path, 'w') as f: # Use 'w' to overwrite
        json.dump(inventory_history, f, indent=4)


def update_seller_inventory_history(data, current_date, current_time):
    """Update sellerAndInventoryUpdateHistory.json (or create a new one for each seller)."""
    # Changed to create a specific history file for each seller
    seller_id = data['sellerId']
    json_file_path = os.path.join(settings.BASE_DIR, f'seller_{seller_id}_inventory_history.json')

    seller_history = {}
    if os.path.exists(json_file_path):
        with open(json_file_path, 'r+') as f:
            try:
                seller_history = json.load(f)
            except json.JSONDecodeError:
                seller_history = {} # Reinitialize if corrupted
    
    # Initialize the seller_history structure if it's new or empty
    if not seller_history:
        seller_history = {
            "sellerId": seller_id,
            "sellerName": data['sellerName'],
            "sellerBranchName": data['sellerBranchName'],
            "sellerBranchAddress": data['sellerBranchAddress'],
            "sellerWarehouseName": data['sellerWarehouseName'],
            "sellerWarehouseAddress": data['sellerWarehouseAddress'],
            "sellerInventoryUpdateHistory": []
        }
    else:
        # Update seller info in history if they have changed
        seller_history['sellerName'] = data['sellerName']
        seller_history['sellerBranchName'] = data['sellerBranchName']
        seller_history['sellerBranchAddress'] = data['sellerBranchAddress']
        seller_history['sellerWarehouseName'] = data['sellerWarehouseName']
        seller_history['sellerWarehouseAddress'] = data['sellerWarehouseAddress']

    # Process inventory updates
    for product_id, update_data in data['inventoryUpdates'].items():
        # Find or create product entry in seller's history
        product = next((p for p in seller_history['sellerInventoryUpdateHistory'] if p['productId'] == product_id), None)
        if not product:
            product = {
                "productId": product_id,
                "productName": update_data['productName'],
                "productVariants": []
            }
            seller_history['sellerInventoryUpdateHistory'].append(product)

        # Find or create variant entry in product's history
        variant = next((v for v in product['productVariants'] if v['variantId'] == update_data['variantId']), None)
        if not variant:
            variant = {
                "variantId": update_data['variantId'],
                "variantName": update_data['variantName'],
                "variantUnitsAvailable": 0, # This will be updated by the sum of added/removed in its own history
                "variantInventoryUpdates": []
            }
            product['productVariants'].append(variant)

        # Update units available based on current update
        variant['variantUnitsAvailable'] += update_data.get('added', 0) - update_data.get('removed', 0)

        # Add inventory update record
        update_record = {
            "variantInventoryUpdatedAtDate": current_date,
            "variantInventoryUpdatedAtTime": current_time,
            "variantUpdatedQuantity": update_data.get('added', 0) - update_data.get('removed', 0),
            "variantUpdatedPrice": update_data.get('price', 0)
        }
        variant['variantInventoryUpdates'].append(update_record)

    # Write back to file
    with open(json_file_path, 'w') as f: # Use 'w' to overwrite or create
        json.dump(seller_history, f, indent=4)





