
from django.http import HttpResponse

from django.urls import path

from . import views





import os

def debug_file_path(request):
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    json_path = os.path.join(base_dir, 'leafyVegetables.json')
    exists = os.path.exists(json_path)
    return HttpResponse(f"""
        <h1>Debug Info</h1>
        <p>Base directory: {base_dir}</p>
        <p>JSON path: {json_path}</p>
        <p>File exists: {exists}</p>
    """)

urlpatterns = [
path("",views.index,name="index"), 
   path('servevegetablestemplate/', views.serve_vegetables_template, name='serve_vegetables_template'),
    path('api/update-inventory/', views.update_inventory, name='update_inventory'),
    # Add other URLs as needed
    path('debug/', debug_file_path),  # Temporary debug route
    path('serveleafyvegetablesinventory/', views.serve_leafy_vegetables_inventory, name='serve_inventory'),
   

    path('serveoverallinventory/', views.serve_overall_inventory, name='serve-overall-inventory'),
    # ... your other URLs ...

]







