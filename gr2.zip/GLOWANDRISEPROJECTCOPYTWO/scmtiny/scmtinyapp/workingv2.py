"""
VEGETABLEWS APP
"""
import os
import json
from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime
import glob

# Ensure the 'data' directory exists within the BASE_DIR
DATA_DIR = os.path.join(settings.BASE_DIR, 'data')
os.makedirs(DATA_DIR, exist_ok=True)

# Path to the master dataset file
MASTER_DATASET_PATH = os.path.join(DATA_DIR, 'master_dataset.json')

# Helper function to initialize the master dataset if it doesn't exist
def initialize_master_dataset():
    if not os.path.exists(MASTER_DATASET_PATH):
        vegetables_data = [
            {
                "vegetable": "Potato",
                "sub_variants": [
                    "Kufri Bahar", "Kufri Jyoti", "Kufri Pukhraj", "Lady Rosetta", "Desi Aloo"
                ]
            },
            {
                "vegetable": "Tomato",
                "sub_variants": [
                    "Arka Rakshak", "Pusa Ruby", "Cherry Tomato", "Hybrid Tomato", "Local Desi Tamatar"
                ]
            },
            {
                "vegetable": "Onion",
                "sub_variants": [
                    "Red Onion", "White Onion", "Shallots (Madras Vengayam)", "Spring Onion"
                ]
            },
            {
                "vegetable": "Brinjal (Eggplant)",
                "sub_variants": [
                    "Long", "Round", "Green", "White", "Bharta Baingan", "Small Brinjal"
                ]
            },
            {
                "vegetable": "Okra (Bhindi)",
                "sub_variants": [
                    "Arka Anamika", "Pusa Sawani", "Hybrid Bhindi"
                ]
            },
            {
                "vegetable": "Cauliflower",
                "sub_variants": [
                    "Early Snowball", "Pusa Snowball", "Hybrid Gobi"
                ]
            },
            {
                "vegetable": "Cabbage",
                "sub_variants": [
                    "Golden Acre", "Pride of India", "Red Cabbage"
                ]
            },
            {
                "vegetable": "Carrot",
                "sub_variants": [
                    "Red Desi Carrot", "Orange Hybrid", "Black Carrot"
                ]
            },
            {
                "vegetable": "Beetroot",
                "sub_variants": [
                    "Detroit Dark Red", "Crimson Globe"
                ]
            },
            {
                "vegetable": "Radish",
                "sub_variants": [
                    "Pusa Chetki", "Pusa Desi", "Japanese White", "Red Radish"
                ]
            },
            {
                "vegetable": "Chilli",
                "sub_variants": [
                    "Green Chillies", "Red Chillies", "Bird's Eye Chilli", "Bhut Jolokia", "Bell Pepper"
                ]
            },
            {
                "vegetable": "Spinach",
                "sub_variants": [
                    "Palak", "Amarnath", "Fenugreek (Methi)"
                ]
            },
            {
                "vegetable": "Capsicum (Bell Pepper)",
                "sub_variants": [
                    "Green Capsicum", "Red Capsicum", "Yellow Capsicum"
                ]
            },
            {
                "vegetable": "Ginger",
                "sub_variants": [
                    "Fresh Ginger", "Dried Ginger"
                ]
            },
            {
                "vegetable": "Garlic",
                "sub_variants": [
                    "Local Garlic", "Himalayan Garlic", "Peeled Garlic"
                ]
            },
            {
                "vegetable": "Mushroom",
                "sub_variants": [
                    "Button Mushroom", "Oyster Mushroom", "Portobello Mushroom", "Shiitake Mushroom"
                ]
            },
            {
                "vegetable": "Pumpkin",
                "sub_variants": [
                    "Red Pumpkin", "White Pumpkin", "Long Pumpkin"
                ]
            },
            {
                "vegetable": "Drumstick",
                "sub_variants": [
                    "Fresh Drumstick", "Dried Drumstick"
                ]
            },
            {
                "vegetable": "Lemon",
                "sub_variants": [
                    "Lime (Small Lemon)", "Sweet Lime (Mosambi)"
                ]
            },
            {
                "vegetable": "Cucumber",
                "sub_variants": [
                    "Local Cucumber",
                    "English Cucumber",
                    "Kakdi"
                ]
            },
            {
                "vegetable": "Bitter Gourd (Karela)",
                "sub_variants": [
                    "Small Karela",
                    "Big Karela"
                ]
            },
            {
                "vegetable": "Ridge Gourd (Turai)",
                "sub_variants": [
                    "Smooth Turai",
                    "Ridged Turai"
                ]
            },
            {
                "vegetable": "Bottle Gourd (Lauki)",
                "sub_variants": [
                    "Long Bottle Gourd",
                    "Round Bottle Gourd"
                ]
            },
            {
                "vegetable": "Sweet Potato",
                "sub_variants": [
                    "Red Sweet Potato",
                    "White Sweet Potato"
                ]
            },
            {
                "vegetable": "Cluster Beans (Gavar)",
                "sub_variants": [
                    "Fresh Gavar"
                ]
            }
        ]
        with open(MASTER_DATASET_PATH, 'w', encoding='utf-8') as f:
            json.dump(vegetables_data, f, indent=4, ensure_ascii=False)
        print(f"Master dataset initialized at {MASTER_DATASET_PATH}")
    else:
        print(f"Master dataset already exists at {MASTER_DATASET_PATH}")

# Call the initializer once when the app starts
initialize_master_dataset()

# Create your views here.
def index(request):
    return render(request, "index.html")

@csrf_exempt # Use this decorator for simplicity in development; for production, handle CSRF tokens properly
def get_vegetable_products(request):
    if request.method == 'POST':
        try:
            # Decode the JSON payload from the request body
            incoming_data = json.loads(request.body)

            store_id = incoming_data.get('StoreId')
            store_name = incoming_data.get('StoreName', 'Not Set')
            store_address = incoming_data.get('StoreAddress', 'Not Set')
            incoming_vegetables = incoming_data.get('vegetables', {})

            if not store_id:
                return JsonResponse({'message': 'StoreId is required'}, status=400)

            # Find the latest inventory file for this store
            # Files are named like: <store_id>_YYYYMMDD_HHMMSS_veg.json
            store_files = glob.glob(os.path.join(DATA_DIR, f"{store_id}_*_veg.json"))
            store_files.sort() # Sort to get the latest file

            current_inventory = {}
            if store_files:
                latest_file_path = store_files[-1]
                with open(latest_file_path, 'r', encoding='utf-8') as f:
                    current_inventory_data = json.load(f)
                    current_inventory = current_inventory_data.get('vegetables', {})
            else:
                # If no existing file, initialize from master dataset
                with open(MASTER_DATASET_PATH, 'r', encoding='utf-8') as f:
                    master_data = json.load(f)
                for veg_item in master_data:
                    veg_name = veg_item['vegetable']
                    current_inventory[veg_name] = {}
                    for sub_variant in veg_item['sub_variants']:
                        current_inventory[veg_name][sub_variant] = {'quantity': 0}

            # Update quantities based on incoming data
            for veg_name, sub_variants_data in incoming_vegetables.items():
                if veg_name not in current_inventory:
                    current_inventory[veg_name] = {} # Add new vegetable if not present

                for sub_variant, details in sub_variants_data.items():
                    incoming_quantity = 0 # Default to 0

                    # Check if 'details' is a dictionary. If not, assume it's the quantity itself.
                    if isinstance(details, dict):
                        incoming_quantity = details.get('quantity', 0)
                    else:
                        # Try to convert to int, handle cases where it's not a number
                        try:
                            incoming_quantity = int(details)
                        except (ValueError, TypeError):
                            print(f"Warning: Unexpected data type for quantity of {veg_name} - {sub_variant}: {details}. Defaulting to 0.")
                            incoming_quantity = 0 # Default to 0 if invalid

                    if sub_variant not in current_inventory[veg_name]:
                        current_inventory[veg_name][sub_variant] = {'quantity': 0} # Initialize if new sub-variant

                    # Update the quantity
                    current_inventory[veg_name][sub_variant]['quantity'] += incoming_quantity

            # Prepare the new data to be saved
            now = datetime.now()
            timestamp_str = now.strftime("%Y%m%d_%H%M%S")
            file_name = f"{store_id}_{timestamp_str}_veg.json"
            file_path = os.path.join(DATA_DIR, file_name)

            data_to_save = {
                "StoreId": store_id,
                "StoreName": store_name,
                "StoreAddress": store_address,
                "timestamp": now.isoformat(), # ISO format for easy parsing later
                "vegetables": current_inventory
            }

            # Save the updated inventory to a new JSON file
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data_to_save, f, indent=4, ensure_ascii=False)

            return JsonResponse({'message': f'Inventory for StoreId {store_id} updated and saved to {file_name}', 'current_inventory_snapshot': current_inventory}, status=200)

        except json.JSONDecodeError:
            return JsonResponse({'message': 'Invalid JSON in request body'}, status=400)
        except Exception as e:
            # For debugging, print the full traceback to the console
            import traceback
            traceback.print_exc()
            return JsonResponse({'message': f'An error occurred: {str(e)}'}, status=500)

    elif request.method == 'GET':
        store_id = request.GET.get('store_id')

        if not store_id:
            return JsonResponse({'message': 'store_id is required for GET request'}, status=400)

        # Try to find the latest file for the given store_id
        store_files = glob.glob(os.path.join(DATA_DIR, f"{store_id}_*_veg.json"))
        store_files.sort()

        if store_files:
            latest_file_path = store_files[-1]
            try:
                with open(latest_file_path, 'r', encoding='utf-8') as f:
                    current_data = json.load(f)
                return JsonResponse({'message': f'Latest inventory for StoreId {store_id}.', 'data': current_data}, status=200)
            except json.JSONDecodeError:
                return JsonResponse({'message': 'Latest file is corrupted JSON.', 'file_path': latest_file_path}, status=500)
            except Exception as e:
                import traceback
                traceback.print_exc()
                return JsonResponse({'message': f'Error reading latest file: {str(e)}'}, status=500)
        else:
            # If no existing file, initialize from master dataset with 0 quantities
            with open(MASTER_DATASET_PATH, 'r', encoding='utf-8') as f:
                master_data = json.load(f)

            initial_vegetables = {}
            for veg_item in master_data:
                veg_name = veg_item['vegetable']
                initial_vegetables[veg_name] = {}
                for sub_variant in veg_item['sub_variants']:
                    initial_vegetables[veg_name][sub_variant] = {'quantity': 0}

            initial_data = {
                "StoreId": store_id,
                "StoreName": "Not Set",
                "StoreAddress": "Not Set",
                "timestamp": datetime.now().isoformat(),
                "vegetables": initial_vegetables
            }
            # Create the initial file with a timestamp
            now = datetime.now()
            timestamp_str = now.strftime("%Y%m%d_%H%M%S")
            file_name = f"{store_id}_{timestamp_str}_veg.json"
            file_path = os.path.join(DATA_DIR, file_name)

            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(initial_data, f, indent=4, ensure_ascii=False)
                return JsonResponse({'message': f'File {file_name} created and initialized with empty data.', 'data': initial_data}, status=201)
            except Exception as e:
                import traceback
                traceback.print_exc()
                return JsonResponse({'message': f'Error creating initial file: {str(e)}'}, status=500)
    else:
        return JsonResponse({'message': 'Method not allowed'}, status=405)


@csrf_exempt
def sales_and_quantity_details(request):
    if request.method == 'GET':
        store_id = request.GET.get('store_id')

        if not store_id:
            return JsonResponse({'message': 'store_id is required for sales and quantity details'}, status=400)

        # Get all files for the given store ID, sorted by timestamp
        store_files = glob.glob(os.path.join(DATA_DIR, f"{store_id}_*_veg.json"))
        # Sort files by their timestamp in the filename
        store_files.sort(key=lambda x: datetime.strptime(os.path.basename(x).split('_')[1] + '_' + os.path.basename(x).split('_')[2].split('.')[0], "%Y%m%d_%H%M%S"))

        if not store_files:
            return JsonResponse({'message': f'No inventory data found for StoreId {store_id}'}, status=404)

        report_data = {} # { vegetable_name: { sub_variant: [] } }

        previous_inventory = {} # To calculate the change

        for file_path in store_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    timestamp_str = data.get('timestamp')
                    current_vegetables = data.get('vegetables', {})

                    if not timestamp_str:
                        # Fallback for older files without 'timestamp' key
                        file_timestamp_part = os.path.basename(file_path).split('_')[1] + '_' + os.path.basename(file_path).split('_')[2].split('.')[0]
                        timestamp_obj = datetime.strptime(file_timestamp_part, "%Y%m%d_%H%M%S")
                    else:
                        timestamp_obj = datetime.fromisoformat(timestamp_str)


                    for veg_name, sub_variants_data in current_vegetables.items():
                        if veg_name not in report_data:
                            report_data[veg_name] = {}

                        for sub_variant, details in sub_variants_data.items():
                            current_quantity = 0 # Default to 0

                            # Check if 'details' is a dictionary. If not, assume it's the quantity itself.
                            if isinstance(details, dict):
                                current_quantity = details.get('quantity', 0)
                            else:
                                try:
                                    current_quantity = int(details)
                                except (ValueError, TypeError):
                                    print(f"Warning: Unexpected data type for quantity in file {file_path} for {veg_name} - {sub_variant}: {details}. Defaulting to 0.")
                                    current_quantity = 0

                            previous_quantity = previous_inventory.get(veg_name, {}).get(sub_variant, {}).get('quantity', 0)
                            quantity_added = current_quantity - previous_quantity

                            if sub_variant not in report_data[veg_name]:
                                report_data[veg_name][sub_variant] = []

                            report_entry = {
                                "date_time": timestamp_obj.strftime("%d/%m/%Y %I:%M%p"), # e.g., 12/06/2025 03:00PM
                                "quantity_change": quantity_added,
                                "total_quantity": current_quantity
                            }
                            report_data[veg_name][sub_variant].append(report_entry)

                    # Update previous inventory for the next iteration
                    previous_inventory = current_vegetables

            except json.JSONDecodeError:
                print(f"Warning: Corrupted JSON file found: {file_path}")
                continue # Skip corrupted files
            except Exception as e:
                import traceback
                traceback.print_exc()
                print(f"Error processing file {file_path}: {str(e)}")
                continue

        # Format the report for display (flattening it for the table)
        final_report = []
        for veg_name, sub_variants in report_data.items():
            for sub_variant, entries in sub_variants.items():
                for entry in entries:
                    final_report.append({
                        "vegetable": veg_name,
                        "sub_variant": sub_variant,
                        "date_time": entry["date_time"],
                        "quantity_change": entry["quantity_change"],
                        "total_quantity": entry["total_quantity"]
                    })
        # Sort the final report by date and time
        final_report.sort(key=lambda x: datetime.strptime(x["date_time"], "%d/%m/%Y %I:%M%p"))

        return JsonResponse({'store_id': store_id, 'report': final_report}, status=200)
    else:
        return JsonResponse({'message': 'Method not allowed'}, status=405)
