
"""
VEGETABLEWS APP
"""
import os
import json
from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
def index(request):
    return render(request, "index.html")

@csrf_exempt # Use this decorator for simplicity in development; for production, handle CSRF tokens properly
def get_vegetable_products(request):
    # Define the base directory for saving JSON files
    save_directory = os.path.join(settings.BASE_DIR, 'data')

    # Ensure the 'data' directory exists
    os.makedirs(save_directory, exist_ok=True)

    if request.method == 'POST':
        try:
            # Decode the JSON payload from the request body
            data = json.loads(request.body)

            store_id = data.get('StoreId')
            store_name = data.get('StoreName')
            store_address = data.get('StoreAddress')
            vegetables = data.get('vegetables', {})

            if not store_id:
                return JsonResponse({'message': 'StoreId is required'}, status=400)

            # Construct the filename
            file_name = f"{store_id}_veg.json"
            file_path = os.path.join(save_directory, file_name)

            # Save the received data to the JSON file
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)

            return JsonResponse({'message': f'Data for StoreId {store_id} saved successfully to {file_name}', 'received_data': data}, status=200)

        except json.JSONDecodeError:
            return JsonResponse({'message': 'Invalid JSON in request body'}, status=400)
        except Exception as e:
            return JsonResponse({'message': f'An error occurred: {str(e)}'}, status=500)
    elif request.method == 'GET': # Handle GET request to create/initialize file
        store_id = request.GET.get('store_id') # Expect store_id as a query parameter for GET

        if not store_id:
            return JsonResponse({'message': 'store_id is required for GET request'}, status=400)

        file_name = f"{store_id}_veg.json"
        file_path = os.path.join(save_directory, file_name)

        if not os.path.exists(file_path):
            # If file doesn't exist, create it with empty initial data
            initial_data = {
                "StoreId": store_id,
                "StoreName": "Not Set", # Placeholder, will be updated on POST
                "StoreAddress": "Not Set", # Placeholder, will be updated on POST
                "vegetables": {}
            }
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(initial_data, f, indent=4, ensure_ascii=False)
                return JsonResponse({'message': f'File {file_name} created and initialized with empty data.', 'data': initial_data}, status=201)
            except Exception as e:
                return JsonResponse({'message': f'Error creating file: {str(e)}'}, status=500)
        else:
            # If file already exists, you might want to return its current content
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    current_data = json.load(f)
                return JsonResponse({'message': f'File {file_name} already exists.', 'data': current_data}, status=200)
            except json.JSONDecodeError:
                return JsonResponse({'message': 'Existing file is corrupted JSON.', 'file_path': file_path}, status=500)
            except Exception as e:
                return JsonResponse({'message': f'Error reading existing file: {str(e)}'}, status=500)
    else:
        return JsonResponse({'message': 'Method not allowed'}, status=405)

