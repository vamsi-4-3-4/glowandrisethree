from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
import os
from django.conf import settings

@csrf_exempt  # Still needed if you want to keep POST capability
def get_product_details(request):
    # Handle both GET and POST requests
    if request.method == 'GET':
        product_id = request.GET.get('productId')
    elif request.method == 'POST':
        try:
            data = json.loads(request.body)
            product_id = data.get('productId')
        except json.JSONDecodeError:
            return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)
    else:
        return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)
    
    if not product_id:
        return JsonResponse({'status': 'error', 'message': 'productId is required'}, status=400)
    
    # Rest of your view logic remains the same...
    try:
        json_file_path = os.path.join(settings.BASE_DIR, 'overallLeafyVegetables.json')
        inventory_path = os.path.join(settings.BASE_DIR, 'overallInventoryUpdateHistory.json')
        
        with open(json_file_path, 'r') as f:
            products = json.load(f)
            
        product = next((p for p in products if p['productId'] == product_id), None)
        
        if product:
            with open(inventory_path, 'r') as f:
                inventory_data = json.load(f)
            
            # Your inventory processing logic...
            
            return JsonResponse({'status': 'success', 'product': product})
        else:
            return JsonResponse({'status': 'error', 'message': 'Product not found'}, status=404)
            
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
