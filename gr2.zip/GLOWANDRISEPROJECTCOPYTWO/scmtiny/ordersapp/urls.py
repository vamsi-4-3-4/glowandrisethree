from django.urls import path
from . import views

urlpatterns = [
    path('get-product-details/', views.get_product_details, name='get_product_details'),
    # your other URLs...
]
