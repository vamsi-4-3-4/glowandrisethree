# starting imports
import json
import random
import os
from django.shortcuts import render, redirect
from django.http import JsonResponse
# ending imports

# Utility to recreate user data JSONs
def recreate_user_data_files():
    file_path = 'registeredusers.json'
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            try:
                users = json.load(file)
            except json.JSONDecodeError:
                users = []

        usernames = []
        useremails = []
        usermobiles = []
        userpasswords = []

        for user in users:
            usernames.append(user['userName'])
            useremails.append(user['userEmail'])
            usermobiles.append(user['userMobile'])
            userpasswords.append({"userEmail": user['userEmail'], "userPassword": user['userPassword']})

        with open('usernames.json', 'w') as f:
            json.dump(usernames, f, indent=4)

        with open('userEmails.json', 'w') as f:
            json.dump(useremails, f, indent=4)

        with open('userMobiles.json', 'w') as f:
            json.dump(usermobiles, f, indent=4)

        with open('userPasswords.json', 'w') as f:
            json.dump(userpasswords, f, indent=4)

# Recreate JSONs on server start
recreate_user_data_files()

# starting index view
def index(request):
    return render(request, "index.html")
# ending index view

# starting register view
def register(request):
    if request.method == 'POST':
        userFullname = request.POST['userFullname']
        userName = request.POST['userName']
        userEmail = request.POST['userEmail']
        userMobile = request.POST['userMobile']
        userGender = request.POST['userGender']
        userDOB = request.POST['userDOB']
        userPassword = request.POST['userPassword']
        products = request.POST.getlist('products')

        userID = ''.join([str(random.randint(0, 9)) for _ in range(10)])

        new_user = {
            "userID": userID,
            "userFullname": userFullname,
            "userName": userName,
            "userEmail": userEmail,
            "userMobile": userMobile,
            "userPassword": userPassword,
            "userGender": userGender,
            "userDOB": userDOB,
            "userPreferredProducts": products,
            "userFingerprint": "n/a",
            "userIris": "n/a",
            "emailVerifiedStatus": "Verified",
            "mobileVerifiedStatus": "Verified",
            "isLoggedin": True
        }

        file_path = 'registeredusers.json'
        if not os.path.exists(file_path):
            with open(file_path, 'w') as file:
                json.dump([], file)

        with open(file_path, 'r') as file:
            try:
                users = json.load(file)
            except json.JSONDecodeError:
                users = []

        users.append(new_user)

        with open(file_path, 'w') as file:
            json.dump(users, file, indent=4)

        # Update the usernames, emails, mobiles, passwords
        recreate_user_data_files()

        return redirect(f'/glowandrise/{userID}/')

    return render(request, 'register.html')
# ending register view

# starting login view
def login(request):
    return render(request, 'login.html')
# ending login view

# starting validate_username_email_mobile view
def validate_user_details(request):
    query = request.GET.get('query', '').lower()

    usernames = []
    useremails = []
    usermobiles = []

    try:
        with open('usernames.json') as f:
            usernames = json.load(f)
        with open('userEmails.json') as f:
            useremails = json.load(f)
        with open('userMobiles.json') as f:
            usermobiles = json.load(f)
    except Exception:
        pass

    result = {
        'valid': False,
        'message': ''
    }

    if query:
        if any(query in username.lower() for username in usernames):
            result['valid'] = True
            result['message'] = 'Username exists.'
        elif any(query in email.lower() for email in useremails):
            result['valid'] = True
            result['message'] = 'Email exists.'
        elif any(query in mobile.lower() for mobile in usermobiles):
            result['valid'] = True
            result['message'] = 'Mobile number exists.'
        else:
            result['valid'] = False
            result['message'] = 'Invalid Username/Email/Mobile.'

    return JsonResponse(result)
# ending validate_username_email_mobile view

# starting validate password view
def validate_password(request):
    email = request.GET.get('email', '')
    password = request.GET.get('password', '')

    try:
        with open('userPasswords.json') as f:
            user_passwords = json.load(f)
    except Exception:
        user_passwords = []

    result = {
        'valid': False,
        'message': ''
    }

    for record in user_passwords:
        if record['userEmail'] == email and record['userPassword'].startswith(password):
            if record['userPassword'] == password:
                result['valid'] = True
                result['message'] = 'Password correct.'
            else:
                result['valid'] = False
                result['message'] = 'Keep typing password...'
            break

    return JsonResponse(result)
# ending validate password view

# starting glowandrise view
def glowandriseappmain(request, userID):
    file_path = 'registeredusers.json'
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            try:
                users = json.load(file)
            except json.JSONDecodeError:
                users = []

        for user in users:
            if user['userID'] == userID and user['isLoggedin']:
                return render(request, 'glowandrise.html', {'user': user})

    return redirect('login')
# ending glowandrise view

# starting logout view
def logout(request, userID):
    file_path = 'registeredusers.json'
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            try:
                users = json.load(file)
            except json.JSONDecodeError:
                users = []

        for user in users:
            if user['userID'] == userID:
                user['isLoggedin'] = False

        with open(file_path, 'w') as file:
            json.dump(users, file, indent=4)

    return redirect('login')
# ending logout view
