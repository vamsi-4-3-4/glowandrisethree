# views.py

import json
import random
import os
from django.shortcuts import render, redirect
from django.http import JsonResponse

def index(request):
    return render(request, "index.html")

def register(request):
    if request.method == 'POST':
        userFullname = request.POST.get('userFullname')
        userName = request.POST.get('userName')
        userEmail = request.POST.get('userEmail')
        userMobile = request.POST.get('userMobile')
        userGender = request.POST.get('userGender')
        userDOB = request.POST.get('userDOB')
        userPassword = request.POST.get('userPassword')
        products = request.POST.getlist('products')

        userID = ''.join([str(random.randint(0, 9)) for _ in range(10)])

        file_path = 'registeredusers.json'
        if not os.path.exists(file_path):
            with open(file_path, 'w') as file:
                json.dump([], file)

        with open(file_path, 'r') as file:
            try:
                users = json.load(file)
            except json.JSONDecodeError:
                users = []

        # Check if username, email, or mobile already exists
        for user in users:
            if user['userName'] == userName:
                return render(request, 'register.html', {"error": "Username already exists"})
            if user['userEmail'] == userEmail:
                return render(request, 'register.html', {"error": "Email already exists"})
            if user['userMobile'] == userMobile:
                return render(request, 'register.html', {"error": "Mobile already exists"})

        new_user = {
            "userID": userID,
            "userFullname": userFullname,
            "userName": userName,
            "userEmail": userEmail,
            "userMobile": userMobile,
            "userPassword": userPassword,
            "userGender": userGender,
            "userDOB": userDOB,
            "userPreferredProducts": products,
            "userFingerprint": "n/a",
            "userIris": "n/a",
            "emailVerifiedStatus": "Verified",
            "mobileVerifiedStatus": "Verified",
            "isLoggedin": True
        }

        users.append(new_user)

        with open(file_path, 'w') as file:
            json.dump(users, file, indent=4)

        # Save separate files
        with open('userNames.json', 'w') as f:
            json.dump([u['userName'] for u in users], f, indent=4)

        with open('userEmails.json', 'w') as f:
            json.dump([u['userEmail'] for u in users], f, indent=4)

        with open('userMobiles.json', 'w') as f:
            json.dump([u['userMobile'] for u in users], f, indent=4)

        return redirect(f'/glowandrise/{userID}/')

    return render(request, 'register.html')





import json
import os
from datetime import datetime, timedelta
from django.shortcuts import render, redirect
from django.http import JsonResponse

REGISTERED_USERS_FILE = 'registeredusers.json'
LOGIN_DETAILS_FILE = 'logindetails.json'

def load_users():
    if os.path.exists(REGISTERED_USERS_FILE):
        with open(REGISTERED_USERS_FILE, 'r') as file:
            try:
                return json.load(file)
            except json.JSONDecodeError:
                return []
    return []

def save_users(users):
    with open(REGISTERED_USERS_FILE, 'w') as file:
        json.dump(users, file, indent=4)

def load_login_details():
    if os.path.exists(LOGIN_DETAILS_FILE):
        with open(LOGIN_DETAILS_FILE, 'r') as file:
            try:
                return json.load(file)
            except json.JSONDecodeError:
                return []
    return []

def save_login_details(details):
    with open(LOGIN_DETAILS_FILE, 'w') as file:
        json.dump(details, file, indent=4)

def login(request):
    if request.method == 'POST':
        userInput = request.POST.get('userIdentity')
        userPassword = request.POST.get('userPassword')

        users = load_users()
        login_details = load_login_details()

        for user in users:
            if (user['userName'] == userInput or user['userEmail'] == userInput or user['userMobile'] == userInput):
                if user['userPassword'] == userPassword:
                    user['isLoggedin'] = True
                    save_users(users)

                    now = datetime.now()
                    login_time = now.strftime("%H:%M:%S")
                    login_date = now.strftime("%Y-%m-%d")

                    # Check if login detail already exists
                    user_login_detail = None
                    for detail in login_details:
                        if detail['userID'] == user['userID']:
                            user_login_detail = detail
                            break

                    if user_login_detail:
                        # Update login attempts
                        user_login_detail['loginAttempts'] += 1
                        user_login_detail['lastloginTime'] = login_time
                        user_login_detail['lastloginDate'] = login_date
                        user_login_detail['lastlogoutTime'] = ''
                        user_login_detail['lastlogoutDate'] = ''
                        user_login_detail['loginDuration'] = ''
                    else:
                        # New entry
                        login_details.append({
                            'userName': user['userName'],
                            'userID': user['userID'],
                            'userMobile': user['userMobile'],
                            'userEmail': user['userEmail'],
                            'lastloginTime': login_time,
                            'lastloginDate': login_date,
                            'lastlogoutTime': '',
                            'lastlogoutDate': '',
                            'loginDuration': '',
                            'loginAttempts': 1
                        })

                    save_login_details(login_details)

                    return redirect(f'/glowandrise/{user["userID"]}/')
                else:
                    return render(request, 'login.html', {"error": "Invalid password"})

        return render(request, 'login.html', {"error": "User not found"})

    return render(request, 'login.html')

def logout(request, userID):
    users = load_users()
    login_details = load_login_details()

    now = datetime.now()
    logout_time = now.strftime("%H:%M:%S")
    logout_date = now.strftime("%Y-%m-%d")

    # Update isLoggedin = false
    for user in users:
        if user['userID'] == userID:
            user['isLoggedin'] = False
            break
    save_users(users)

    # Update logout details and calculate duration
    for detail in login_details:
        if detail['userID'] == userID:
            detail['lastlogoutTime'] = logout_time
            detail['lastlogoutDate'] = logout_date

            try:
                login_time_str = detail['lastloginTime']
                login_datetime = datetime.strptime(detail['lastloginDate'] + " " + login_time_str, "%Y-%m-%d %H:%M:%S")
                logout_datetime = datetime.strptime(logout_date + " " + logout_time, "%Y-%m-%d %H:%M:%S")

                duration = logout_datetime - login_datetime
                # Save duration as string in HH:MM:SS
                detail['loginDuration'] = str(duration)
            except Exception as e:
                print(f"Error calculating duration: {e}")
                detail['loginDuration'] = ''

            break

    save_login_details(login_details)

    return redirect('login')

def glowandrise(request, userID):
    file_path = 'registeredusers.json'
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            try:
                users = json.load(file)
            except json.JSONDecodeError:
                users = []

        for user in users:
            if user['userID'] == userID and user['isLoggedin']:
                return render(request, 'glowandrise.html', {'user': user})

    return redirect('login')




""" old working"""

import json
import os
from django.http import JsonResponse
from django.shortcuts import redirect

# Path to your registered_users.json file
USERS_FILE = 'registeredusers.json'

def load_users():
    if not os.path.exists(USERS_FILE):
        return []
    with open(USERS_FILE, 'r') as file:
        try:
            return json.load(file)
        except json.JSONDecodeError:
            return []

def save_users(users):
    with open(USERS_FILE, 'w') as file:
        json.dump(users, file, indent=4)

def validate_user_details(request):
    query = request.GET.get('query', '').lower()
    users = load_users()

    for user in users:
        if (
            user.get('userEmail', '').lower() == query or
            user.get('userMobile', '').lower() == query or
            user.get('userName', '').lower() == query
        ):
            return JsonResponse({'message': 'User found. Please proceed to enter password.'})

    return JsonResponse({'message': 'No matching user found. Please enter correct details.'})

def validate_password(request):
    email_or_mobile_or_username = request.GET.get('email', '').lower()
    password = request.GET.get('password', '')
    users = load_users()

    for idx, user in enumerate(users):
        if (
            user.get('userEmail', '').lower() == email_or_mobile_or_username or
            user.get('userMobile', '').lower() == email_or_mobile_or_username or
            user.get('userName', '').lower() == email_or_mobile_or_username
        ):
            if user.get('userPassword', '') == password:
                # Update isLoggedin status to true
                users[idx]['isLoggedin'] = True
                save_users(users)
                user_id = user.get('userID')
                # Redirect to /glowandrise/userID
                return JsonResponse({'message': 'Login successful.', 'redirect_url': f'/glowandrise/{user_id}'})
            else:
                return JsonResponse({'message': 'Incorrect password.'})

    return JsonResponse({'message': 'User not found. Please check your details.'})




from django.http import JsonResponse
import json
import os

USERS_FILE = 'registeredusers.json'

def load_users():
    if not os.path.exists(USERS_FILE):
        return []
    with open(USERS_FILE, 'r') as file:
        try:
            return json.load(file)
        except json.JSONDecodeError:
            return []

def validate_user_details_register(request):
    query = request.GET.get('query', '').lower()
    users = load_users()

    for user in users:
        if user.get('userEmail', '').lower() == query:
            return JsonResponse({'message': 'User email already registered. Please enter another.'})
        elif user.get('userMobile', '').lower() == query:
            return JsonResponse({'message': 'User mobile already registered. Please enter another.'})
        elif user.get('userName', '').lower() == query:
            return JsonResponse({'message': 'Username already taken. Please enter another one.'})

    return JsonResponse({'message': 'Available. You can proceed.'})





"""LEARN SECTION VIEWS"""

"""BELOW ARE WORKING DONT DISTRUB"""


"""

import json
import os
from django.shortcuts import render, Http404

# Define the path to your JSON files
REGISTERED_USERS_FILE = 'registeredusers.json'

def get_user_from_json(user_id):
    try:
        with open(REGISTERED_USERS_FILE, 'r') as file:
            users = json.load(file)
        for user in users:
            if user.get('userID') == str(user_id):
                return user
        raise Http404("User not found")
    except FileNotFoundError:
        raise Http404("User data file not found")
    except json.JSONDecodeError:
        raise Http404("Error reading user data")

def profile_view(request, user_id):
    user = get_user_from_json(user_id)
    return render(request, 'profile.html', {'user': user})

def consultations_view(request, user_id):
    user = get_user_from_json(user_id)
    return render(request, 'consultations.html', {'user': user})

def learn_view(request, user_id):
    user = get_user_from_json(user_id)
    return render(request, 'learn.html', {'user': user})

def products_view(request, user_id):
    user = get_user_from_json(user_id)
    return render(request, 'products.html', {'user': user})

def courses_view(request, user_id):
    user = get_user_from_json(user_id)
    return render(request, 'courses.html', {'user': user})

def remedies_view(request, user_id):
    user = get_user_from_json(user_id)
    return render(request, 'naturalremedies.html', {'user': user})
"""

"""ABOVE ARE WORKING DONT  REMOVE"""



import json
import os
from django.shortcuts import render, redirect, Http404
from django.views.decorators.cache import never_cache

REGISTERED_USERS_FILE = 'registeredusers.json'

def get_user_from_json(user_id):
    try:
        with open(REGISTERED_USERS_FILE, 'r') as file:
            users = json.load(file)
        for user in users:
            if user.get('userID') == str(user_id):
                return user
        raise Http404("User not found")
    except FileNotFoundError:
        raise Http404("User data file not found")
    except json.JSONDecodeError:
        raise Http404("Error reading user data")

def check_login(user):
    if not user.get('isLoggedin', False):
        return False
    return True






"""
"""

@never_cache
def profile_view(request, user_id):
    user = get_user_from_json(user_id)
    if not check_login(user):
        return redirect('login')
    return render(request, 'profile.html', {'user': user})

@never_cache
def veg_products_view(request, user_id):
    user = get_user_from_json(user_id)
    if not check_login(user):
        return redirect('login')
    return render(request, 'vegproducts.html', {'user': user})

@never_cache
def nonveg_products_view(request, user_id):
    user = get_user_from_json(user_id)
    if not check_login(user):
        return redirect('login')
    return render(request, 'nonvegproducts.html', {'user': user})

@never_cache
def seafood_products_view(request, user_id):
    user = get_user_from_json(user_id)
    if not check_login(user):
        return redirect('login')
    return render(request, 'seafoodproducts.html', {'user': user})

@never_cache
def dairy_products_view(request, user_id):
    user = get_user_from_json(user_id)
    if not check_login(user):
        return redirect('login')
    return render(request, 'dairyproducts.html', {'user': user})

@never_cache
def veg_nonveg_pickles_view(request, user_id):
    user = get_user_from_json(user_id)
    if not check_login(user):
        return redirect('login')
    return render(request, 'vegandnonvegpickels.html', {'user': user})

@never_cache
def veg_pickles_view(request, user_id):
    user = get_user_from_json(user_id)
    if not check_login(user):
        return redirect('login')
    return render(request, 'vegpickels.html', {'user': user})

@never_cache
def nonveg_pickles_view(request, user_id):
    user = get_user_from_json(user_id)
    if not check_login(user):
        return redirect('login')
    return render(request, 'nonvegpickels.html', {'user': user})

@never_cache
def sweets_view(request, user_id):
    user = get_user_from_json(user_id)
    if not check_login(user):
        return redirect('login')
    return render(request, 'sweets.html', {'user': user})

@never_cache
def hot_snacks_view(request, user_id):
    user = get_user_from_json(user_id)
    if not check_login(user):
        return redirect('login')
    return render(request, 'hotsnacks.html', {'user': user})
