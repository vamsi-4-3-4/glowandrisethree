from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("register/", views.register, name="register"),
    path("login/", views.login, name="login"),
    path("glowandriseappmain/<str:userID>/", views.glowandriseappmain, name="glowandriseappmain"),
    path("logout/<str:userID>/", views.logout, name="logout"),
    # Correct API paths (match your view names)
    path("api/validate-user-details/", views.validate_user_details, name="validate_user_details"),
    path("api/validate-password/", views.validate_password, name="validate_password"),
]
