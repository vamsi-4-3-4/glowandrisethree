from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('glowandrise/<str:userID>/', views.glowandrise, name='glowandrise'),
    path('logout/<str:userID>/', views.logout, name='logout'),

    # Profile and product pages
    path('profile/<int:user_id>/', views.profile_view, name='profile'),
    path('veg-products/<int:user_id>/', views.veg_products_view, name='veg_products'),
    path('nonveg-products/<int:user_id>/', views.nonveg_products_view, name='nonveg_products'),
    path('seafood-products/<int:user_id>/', views.seafood_products_view, name='seafood_products'),
    path('dairy-products/<int:user_id>/', views.dairy_products_view, name='dairy_products'),
    path('veg-nonveg-pickles/<int:user_id>/', views.veg_nonveg_pickles_view, name='veg_nonveg_pickles'),
    path('veg-pickles/<int:user_id>/', views.veg_pickles_view, name='veg_pickles'),
    path('nonveg-pickles/<int:user_id>/', views.nonveg_pickles_view, name='nonveg_pickles'),
    path('sweets/<int:user_id>/', views.sweets_view, name='sweets'),
    path('hot-snacks/<int:user_id>/', views.hot_snacks_view, name='hot_snacks'),

    # AJAX routes
    path('validate_user_details/', views.validate_user_details, name='validate_user_details'),
    path('validate_password/', views.validate_password, name='validate_password'),
    path('validate_user_details_register/', views.validate_user_details_register, name='validate_user_details_register'),
]
