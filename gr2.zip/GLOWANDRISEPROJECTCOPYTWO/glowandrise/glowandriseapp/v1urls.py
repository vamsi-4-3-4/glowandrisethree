# starting imports
from django.urls import path
from . import views
# ending imports

# starting urlpatterns
urlpatterns = [
    # starting index route
    path("", views.index, name="index"),
    # ending index route

    # starting register route
    path('register/', views.register, name='register'),
    # ending register route

    # starting login route
    path('login/', views.login, name='login'),
    # ending login route

    # starting glowandrise route
    path('glowandrise/<str:userID>/', views.glowandrise, name='glowandrise'),
    # ending glowandrise route

    # starting logout route
    path('logout/<str:userID>/', views.logout, name='logout'),
    # ending logout route
]
# ending urlpatterns
