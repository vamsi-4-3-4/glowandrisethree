# starting imports
import json
import random
import os
from django.shortcuts import render, redirect
from django.http import JsonResponse
# ending imports

# starting index view
def index(request):
    return render(request, "index.html")
# ending index view

# starting register view
def register(request):
    if request.method == 'POST':
        userFullname = request.POST['userFullname']
        userName = request.POST['userName']
        userEmail = request.POST['userEmail']
        userMobile = request.POST['userMobile']
        userGender = request.POST['userGender']
        userDOB = request.POST['userDOB']
        userPassword = request.POST['userPassword']
        products = request.POST.getlist('products')

        userID = ''.join([str(random.randint(0, 9)) for _ in range(10)])

        new_user = {
            "userID": userID,
            "userFullname": userFullname,
            "userName": userName,
            "userEmail": userEmail,
            "userMobile": userMobile,
            "userPassword": userPassword,
            "userGender": userGender,
            "userDOB": userDOB,
            "userPreferredProducts": products,
            "userFingerprint": "n/a",
            "userIris": "n/a",
            "emailVerifiedStatus": "Verified",
            "mobileVerifiedStatus": "Verified",
            "isLoggedin": True
        }

        file_path = 'registeredusers.json'
        if not os.path.exists(file_path):
            with open(file_path, 'w') as file:
                json.dump([], file)

        with open(file_path, 'r') as file:
            try:
                users = json.load(file)
            except json.JSONDecodeError:
                users = []

        users.append(new_user)

        with open(file_path, 'w') as file:
            json.dump(users, file, indent=4)

        return redirect(f'/glowandrise/{userID}/')  # Redirect to glowandrise with userID

    return render(request, 'register.html')
# ending register view

# starting login view
def login(request):
    if request.method == 'POST':
        userEmail = request.POST['userEmail']
        userPassword = request.POST['userPassword']

        file_path = 'registeredusers.json'
        if os.path.exists(file_path):
            with open(file_path, 'r') as file:
                try:
                    users = json.load(file)
                except json.JSONDecodeError:
                    users = []

            for user in users:
                if user['userEmail'] == userEmail and user['userPassword'] == userPassword:
                    user['isLoggedin'] = True

                    # update isLoggedin in file
                    with open(file_path, 'w') as file:
                        json.dump(users, file, indent=4)

                    return redirect(f'/glowandrise/{user["userID"]}/')

    return render(request, 'login.html')
# ending login view

# starting glowandrise view
def glowandrise(request, userID):
    file_path = 'registeredusers.json'
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            try:
                users = json.load(file)
            except json.JSONDecodeError:
                users = []

        for user in users:
            if user['userID'] == userID and user['isLoggedin']:
                return render(request, 'glowandrise.html', {'user': user})

    return redirect('login')  # if not logged in
# ending glowandrise view

# starting logout view
def logout(request, userID):
    file_path = 'registeredusers.json'
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            try:
                users = json.load(file)
            except json.JSONDecodeError:
                users = []

        for user in users:
            if user['userID'] == userID:
                user['isLoggedin'] = False

        with open(file_path, 'w') as file:
            json.dump(users, file, indent=4)

    return redirect('login')
# ending logout view
